"use strict";

function revelation(selecteurCSS) {
    /* Rend visible l'élément "selecteurCSS" passé en paramètre. */
    let element = document.querySelector(selecteurCSS)
    element.style.visibility = "visible";
}

function valider(qcm, bonneReponse, rep, com) {
    /* Fonction à écrire par les élèves : A VOUS DE JOUER !
    Entrées :
    - qcm : valeur de l'attribut "name" des boutons radios ciblés. 
    - bonneReponse : valeur de l'attribut "value" du bouton radio correspondant à la réponse attendue.
    - rep : sélecteur CSS de l'élément où afficher la réponse du joueur.
    - com : sélecteur CSS de l'élément où afficher le commentaire d'explication de la réponse.
    

    Lors du clic  sur le bouton "valider", on veut que :
    1- la réponse du joueur s'affiche dans la zone prévue à cet effet.
    2- si la réponse est correcte, elle s'affiche sur fond vert; et sur fond rouge si elle est fausse.
    3- le commentaire de la solution doit aussi s'afficher.
    4- les boutons radios ne doivent plus apparaitre pour ne plus pouvoir changer de réponse.


    Aides : 
    a) on peut obtenir une variable désigannt l'ensemble des boutons radios d'une question avec l'instruction suivante :  let radios = document.getElementsByName(qcm);
    b) on peut utiliser les autres fonctions définies dans ce fichier.
    */

}

function extraitReponse(radios) {
    /* Renvoie la valeur de l'attribut "value" du bouton sélectionné parmi les boutons radios passés en paramètre. 
    Entrée : radios : c'est la valeur de l'attribut "name" des boutons radios ciblés.
    */
    let reponse = "";
    for (let i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            reponse = radios[i].value;
        }
    }
    return reponse
}

function annulerQCM(radios) {
    /* Rend invisible tous les boutons radios qui n'ont pas été sélectionnés par le joueur après avoir cliqué sur le bouton valider (ça empêche de jouer plusieurs fois sur la même question).
    */
    for (let i = 0; i < radios.length; i++) {
        if (! radios[i].checked) {
            radios[i].style.visibility = "hidden";
        }
    }
}