"use strict";


function clair() {
    let mot = document.querySelector('#magie2');
    mot.style.color = "black";
    mot.style.backgroundColor = "white";
}

function sombre() {
    let mot = document.querySelector('#magie2');
    mot.style.color = "white";
    mot.style.backgroundColor = "black";
}

function noirBlanc() {
    let mot = document.querySelector('#texteChangeant');
    mot.style.color = "black";
    mot.style.backgroundColor = "white";
    mot.textContent = "Blanc";
}

function annuler() {
    let mot = document.querySelector('#texteChangeant');
    mot.style.color = "white";
    mot.style.backgroundColor = "black";
    mot.textContent = "Noir";
}

function couleur(coul) {
    let mot = document.querySelector('#texteChangeant');
    mot.style.color = "white";
    mot.style.backgroundColor = coul;
    if (coul == "red") {
        mot.textContent = "Rouge";
    }
    else if (coul == "green") {
        mot.textContent = "Vert";
    }
    else if (coul == "blue") {
        mot.textContent = "Bleu";
    }
}

function arcEnCiel(couleur) {
    let item = document.querySelector('#' + couleur + "Div");
    if (document.querySelector('#' + couleur).checked) {
        item.style.backgroundColor = couleur;
    }
    else {
        item.style.backgroundColor = "rgb(243, 243, 203)";
    }
}

let boutonJS = document.querySelector("#js");
boutonJS.addEventListener("click", btnClic);    /* Ajout d'un gestionnaire d'événement à la main */
let compteur = 1;
function btnClic() {
    boutonJS.textContent = compteur + " clics";
    compteur++;
}

let img = document.querySelector("#tbl");
img.addEventListener("mouseover", complement); /* Ajout du gestionnaire d'événement mouseover */
img.addEventListener("mouseout", complement);  /* Ajout du gestionnaire d'événement mouseout  */
let source = "tbl.jpg";
function complement() {
    if (source == "tbl.jpg") {
        source = "tbl-negatif.jpg";
    } else {
        source = "tbl.jpg";
    }
    img.src = source;
}

function raz() {
    /* déselectionne les cases à cocher et les boutons radio */
    let check = document.getElementsByName('arcenciel');
    for (let i = 0; i < check.length; i++) {
        check[i].checked = false;
    }
    let radio = document.getElementsByName('couleur');
    for (let i = 0; i < radio.length; i++) {
        radio[i].checked = false;
    }
}